from flask import Flask,render_template,request,flash,session
from  hashlib import  sha1
import  json
import tushare as ts
import pymysql

app = Flask(__name__)

@app.route('/search',methods=['GET','POST'])
def search():
    stockName = request.form.get("stockName")
    print(stockName)
    return render_template("search.html")

@app.route('/')
def hello_world():
    return render_template("candlestick-sh.html")


def getHis(stock_code):

    data = json.loads(request.form.get('data'))
    conn = pymysql.connect(db="stock", user="root", password="1101", host="127.0.0.1",
                           port=3306)
    cur = conn.cursor()
    cur.execute("select * from historydata where stock_code = \'"+ str(stock_code)+"\';")
    hisRow = cur.fetchall()
    result = json.dumps(hisRow)
    conn.commit()
    conn.close()
    return result


if __name__ == '__main__':
    app.debug = True
    app.run()
