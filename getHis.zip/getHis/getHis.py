import tushare as ts
import pymysql
import json


def get_codestock_local():  # 从本地获取所有股票代号和名称
    conn = pymysql.connect(database="stock", user="root", password="1101", host="127.0.0.1",
                           port=3306)
    cur = conn.cursor()
    # 创建stocks表
    cur.execute('''
            select * from stocks;
           ''')
    rows = cur.fetchall()
    conn.commit()
    conn.close()

    return rows
    pass


def db_perstock_insertsql(stock_code, cns_name):  # 返回的是插入语句
    sql_temp = "insert into stocks values("
    sql_temp += "\'" + stock_code + "\'" + "," + "\'" + cns_name + "\'"
    sql_temp += ");"
    return sql_temp
    pass


def db_stocks_update():  # 根据gettodayall的情况插入原表中没的。。gettodayall中有的源表没的保留不删除#返回新增行数
    ans = 0
    conn = pymysql.connect(database="stock", user="root", password="1101", host="127.0.0.1", port=3306)

    cur = conn.cursor()
    todayall = ts.get_today_all()
    for i in range(0, len(todayall)):
        sql_temp = "select * from stocks where stock_code="
        sql_temp += "\'" + todayall["code"][i] + "\';"
        cur.execute(sql_temp)
        rows = cur.fetchall()
        if (len(rows) == 0):
            cur.execute(db_perstock_insertsql(todayall["code"][i], todayall["name"][i]))
            print(i)

    conn.commit()
    conn.close()
    print("db_stocks_update finish")
    return ans


def db_stocks_create():
    conn = pymysql.connect(db="stock", user="root", password="1101", host="127.0.0.1",
                           port=3306)
    cur = conn.cursor()
    # 创建stocks表
    cur.execute("create table if not exists stocks(stock_code varchar(20) primary key,cns_name varchar(30));")
    conn.commit()
    conn.close()
    print("db_stocks_create finish")
    pass


def db_historyData_create():
    conn = pymysql.connect(db="stock", user="root", password="1101", host="127.0.0.1",
                           port=3306)
    cur = conn.cursor()
    # 创建stocks表
    cur.execute(
        "create table if not exists historyData(stock_code varchar(20),date varchar(20),open float,high float,close float,low float, primary key(stock_code,date));")
    conn.commit()
    conn.close()
    print("db_historyData_create finish")


def getHisData(stock_code):
    hisData = ts.get_hist_data(stock_code, start='2019-01-05', end='2019-6-09')
    conn = pymysql.connect(db="stock", user="root", password="1101", host="127.0.0.1",
                           port=3306)
    cur = conn.cursor()
    for i in range(0, len(hisData)):
        sql_temp = "select * from historyData where stock_code="
        sql_temp += "\'" + stock_code + "\' and date = \'" + hisData.index[i] + "\';"
        cur.execute(sql_temp)
        rows = cur.fetchall()
        mysql=""
        if (len(rows) == 0):
            mysql ="insert into historyData values(\'" + stock_code + "\', \'" + str(hisData.index[i])
            mysql += "\' , \'" + str(hisData["open"][i]) + "\', \'" + str(hisData["high"][i]) + "\', \'"
            mysql += str(hisData["close"][i]) + "\', \'" + str(hisData["low"][i]) + "\');"
            cur.execute(mysql)
            print(i)
    conn.commit()
    conn.close()

def getStockHisData():
    conn = pymysql.connect(db="stock", user="root", password="1101", host="127.0.0.1",
                           port=3306)
    cur = conn.cursor()
    cur.execute("select stock_code from stocks;")
    codes = cur.fetchall()
    for code in codes:
        getHisData(code[0])
    conn.commit()
    conn.close()

def aa(stock_code):
    conn = pymysql.connect(db="stock", user="root", password="1101", host="127.0.0.1",
                           port=3306)
    cur = conn.cursor()
    cur.execute("select date,open,close,high,low from historydata where stock_code = \'" + str(stock_code) + "\';")
    hisRow = cur.fetchall()
    print(json.dumps(hisRow))
    conn.commit()
    conn.close()

if __name__ == "__main__":
    #db_stocks_create()
    #db_stocks_update()
    #db_historyData_create()
    #getHisData('603899')
    #getStockHisData()
    aa(603677)